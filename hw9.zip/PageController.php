<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function home() {
        return view('views/home', ['activePage' => 'home']);
    }

    public function photos() {
        return view('views/photos', ['activePage' => 'photos']);
    }

    public function contact() {
        return view('views/contact', ['activePage' => 'contact']);
    }
}
