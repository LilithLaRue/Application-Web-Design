<?php
function isActive($name, $active) {
    return $name === $active ? 'style="font-weight: bold;"' : '';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Menus Project</title>
</head>
<body>
    <nav>
        <a href="?page=home" <?= isActive('home', $activePage) ?>>Home</a> |
        <a href="?page=photos" <?= isActive('photos', $activePage) ?>>Photos</a> |
        <a href="?page=contact" <?= isActive('contact', $activePage) ?>>Contact</a>
    </nav>
    <hr>
