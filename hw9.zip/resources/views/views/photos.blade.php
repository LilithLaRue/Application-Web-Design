@include('views.header')

<h1>Photos Gallery</h1>
<p>Enjoy our collection of awesome photos.</p>

@include('views.footer')
