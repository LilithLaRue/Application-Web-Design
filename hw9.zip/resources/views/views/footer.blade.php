    </div> <!-- /.content-wrapper -->

    <footer class="main-footer text-center">
        <strong>Created by Lilith Alejandra Inzunza | Activity 11</strong>
    </footer>
</div> <!-- /.wrapper -->

<script src="{{ asset('adminlte/plugins/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('adminlte/plugins/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
<script src="{{ asset('adminlte/js/adminlte.min.js') }}"></script>
</body>
</html>
