@include('views.header')

<h1>Contact Us</h1>
<p>You can reach us at email@example.com or call 123-456-7890.</p>

@include('views.footer')
