<?php

class PageController {
    private $validPages = ['home', 'photos', 'contact'];

    public function render($page) {
        if (!in_array($page, $this->validPages)) {
            $page = 'home'; // fallback
        }

        $activePage = $page;

        include 'views:header.php';
        include "views:$page.php";
        include 'views:footer.php';
    }
}
